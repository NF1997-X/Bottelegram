# Telegram File Sharing Bot

## Overview
This project is a Telegram File Sharing Bot cloned from [CodeXBotz/File-Sharing-Bot](https://github.com/CodeXBotz/File-Sharing-Bot). The bot stores posts and documents in a specified channel and allows users to access them through special links.

## Current State
- **Status**: Bot is running successfully  
- **Date Setup**: October 17, 2025
- **Project Location**: Root directory (`/`)

## Features
- Store files in a Telegram database channel
- Generate shareable links for files (single or batch)
- Force subscribe functionality
- Protect content from forwarding (optional)
- Auto-delete files after configurable time
- Custom captions and messages
- Broadcast messages to users
- User statistics and bot uptime tracking

## Configuration
The bot is configured using environment variables (stored in Replit Secrets):
- `TG_BOT_TOKEN` - Bot token from @BotFather
- `APP_ID` - Telegram API ID from my.telegram.org
- `API_HASH` - Telegram API Hash
- `CHANNEL_ID` - Database channel ID
- `OWNER_ID` - Owner Telegram user ID
- `DATABASE_URL` - PostgreSQL connection string (auto-configured by Replit)

## Tech Stack
- **Language**: Python 3.11
- **Framework**: Pyrogram (Telegram MTProto API)
- **Database**: PostgreSQL (Replit built-in)
- **Key Libraries**:
  - pyrogram - Telegram client library
  - TgCrypto - Cryptography for Pyrogram
  - pyromod - Pyrogram modifications
  - psycopg2-binary - PostgreSQL driver
  - aiohttp - Async HTTP client

## Project Structure
```
/
├── bot.py              # Main bot client
├── main.py             # Entry point
├── config.py           # Configuration & environment variables
├── helper_func.py      # Helper functions
├── database/           # Database operations
│   ├── __init__.py
│   └── database.py     # PostgreSQL database functions
└── plugins/            # Bot command handlers
    ├── start.py        # Start command & file sharing
    ├── link_generator.py # Link generation commands
    ├── channel_post.py # Channel post handling
    ├── cbb.py          # Callback handlers
    └── route.py        # Web routes
```

## Admin Commands
- `/start` - Start bot or get posts
- `/batch` - Create link for multiple posts
- `/genlink` - Create link for single post
- `/users` - View bot statistics
- `/broadcast` - Broadcast messages to users
- `/stats` - Check bot uptime

## Workflow
- **Name**: Telegram Bot
- **Command**: `python3 main.py`
- **Status**: Running
- **Output**: Console
- **Web Server**: Port 8080 (for deployments)

## Deployment Configuration
- **Type**: Autoscale
- **Run Command**: `python3 main.py`
- **Health Check**: GET / on port 8080
- **Status**: Ready to deploy

## Setup Requirements
1. Create a Telegram bot via @BotFather
2. Get API credentials from my.telegram.org
3. Create a database channel and add bot as admin
4. PostgreSQL database (automatically configured by Replit)
5. Configure all environment variables
6. Bot must be added to database channel with all permissions
7. Optional: Add bot to force subscribe channel as admin

## Recent Changes
- October 17, 2025: Initial setup and deployment on Replit
  - Cloned repository from GitHub
  - Installed Python dependencies
  - Configured environment variables
  - Set up and started bot workflow
  - Bot successfully running and connected to Telegram
  
- October 17, 2025: Migrated from MongoDB to PostgreSQL
  - Created Replit PostgreSQL database
  - Created users table schema
  - Updated requirements.txt to use psycopg2-binary
  - Rewrote database/database.py for PostgreSQL compatibility
  - Successfully tested and deployed with PostgreSQL

- October 17, 2025: Configured for Autoscale Deployment
  - Updated PORT configuration to use 8080 (required for Autoscale)
  - Verified health check endpoint at / responds with 200 OK
  - Configured deployment type as Autoscale
  - Set proper run command for deployment
  - Bot now ready for 24/7 deployment on Replit

- October 17, 2025: Fixed Deployment Issues
  - Removed Telegram session files causing AUTH_KEY_DUPLICATED errors
  - Added session files to .gitignore to prevent future conflicts
  - Reorganized bot startup to start web server BEFORE Telegram operations
  - Health check now passes immediately on deployment
  - Fixed project structure and run command paths
  - Recreated database module in root directory
  - All deployment blockers resolved
  - Deployment run command: `python3 main.py`
